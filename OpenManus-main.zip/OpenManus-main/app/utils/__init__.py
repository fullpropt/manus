# Utility functions and constants for agent tools
